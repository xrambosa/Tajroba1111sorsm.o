<?php 

// تابع المبرمج رامبو @BB55IL
// قناتي » @BB55I //
// معرفي » @BB55Il //

ob_start();
$token = "7356524697:AAFe4M7J-CGZSmSfGkXOXsZfDIQM7KF9WhA"; // توكن بوتك
define('API_KEY',$token);
function bot($method,$datas=[]){$BOT_SYRIA = http_build_query($datas);
$url = "https://api.telegram.org/bot".API_KEY."/".$method."?$BOT_SYRIA";
$BOTS_SYR1A = file_get_contents($url); return json_decode($BOTS_SYR1A);}
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$text = $message->text;
$name = $message->from->first_name;
$username = $message->from->username;
$chat_id2 = $update->callback_query->message->chat->id;
$idss = $update->callback_query->message->chat->id;
$namee = $update->callback_query->message->chat->first_name;
$userr = $update->callback_query->message->chat->username;
$message_id = $update->callback_query->message->message_id;
$data = $update->callback_query->data;
$from_id = $message->from->id;
$ch1 = file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=@BB55Il&user_id=$from_id");
$ch2 = file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=@BB55Il&user_id=$from_id");
$check_token = file_get_contents("https://api.telegram.org/bot$text/getWebhookInfo");
$check = json_decode($check_token);
$get_file = file_get_contents('SourceBot.php');
$get_done = file_get_contents('make/ex.txt');
$done = explode("\n", $get_done);
$get_id = file_get_contents('make/make.txt');
$getid = explode("\n", $get_id);
$mid = $message->message_id;
$inlineqt = $update->inline_query->query;

if($text == '/start' and !in_array($from_id, $getid) and !strpos($ch1 , '"status":"left"') !== false){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"
🚸┊اهلا بك $name 👋

♡┊في بوت صنع بوتات حماية ⚙️🔒

♡┊من احدث المصانع حماية مجموعات✅.

♡┊تستطيع تغيير حقوق بوتك باي وقت وبسهولة💻. 

♡┊اصنع بوتك الان مجاني للابد✅. 

♡┊لصنع بوت جديد اضغط صنع بوت 
📡 CH - @BB55Il
👨‍💻 DEV - الوصف @CIJlX



",
'reply_markup'=>json_encode([
'inline_keyboard'=>[

[['text'=>'صنع بوت 📮','callback_data'=>'maka'],['text'=>'حذف بوت 🗑 ','callback_data'=>'delete']
],
[
['text'=>'المطور ♻','url'=>'t.me/CIJlX']
],
[['text'=>'قناتنا 📢','url'=>'https://t.me/BB55Il'] ,
['text'=>'شارك البوت 🔁','switch_inline_query'=>'']
],
[
['text'=>'بوتاتي المصنوعة 🤖','callback_data'=>'mybots'],['text'=>"",'callback_data'=>"update"]
],
[['text'=>'معلومات حسابي 👤','callback_data'=>'info']],


]
])
]);
}
if($data == 'maka' and !in_array($chat_id2,$done) and !strpos($ch1 , '"status":"left"') !== false){
file_put_contents('make/make.txt', "\n" . $chat_id2 . "\n",FILE_APPEND);    
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>'حسنا !! قم بارسال توكن بوتك الان ✅

- *OK !! Send Your Bot Token Now*✅',
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'العودة | Back','callback_data'=>'cancle']]
]
])
]);
}

if($data == 'maka' and in_array($chat_id2,$done) and !strpos($ch1 , '"status":"left"') !== false){

bot('answerCallbackQuery',[
'callback_query_id'=>$update->callback_query->id,
'message_id'=>$message_id,
'text'=>'لقد قمت بانشاء بوت من قبل ❌

- *You Have Created a bot Before* ❌',
'parse_mode'=>"markdown",
 'show_alert'=>true
 ]);      
}


if($text and in_array($from_id, $getid) and $check->ok == "true"){

for($i = $mid - 3; $i < $mid; $i++){
bot('deleteMessage',[
'chat_id'=>$chat_id,
'message_id'=>$i
]);
}

$url = json_decode(file_get_contents("https://api.telegram.org/bot$text/getme"))->result;
$un = $url->username;
$fttt = $url->first_name;

$str = str_replace($from_id, '', $get_id);    

file_put_contents('make/make.txt', $str);    

file_put_contents('make/ex.txt', $from_id . "\n", FILE_APPEND);
    
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"اكتمل انشاء البوت ✅

- [اضغط هنا للدخول للبوت](t.me/$un) ✅

- *The Bot Will Done* ! ✅

- [Go to your Bot](t.me/$un) ✅",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'العودة | Back' , 'callback_data'=>"home"]
],
]
])

]); 

mkdir("bots/$from_id");
mkdir("bots/$from_id/data");

file_put_contents("bots/$from_id/info.php",$text . "\n" . $from_id . "\n" . $username);

file_put_contents("bots/$from_id/bot.php", $get_file);

file_put_contents("bots/$from_id/chat.txt", $from_id . "\n");


file_get_contents("https://api.telegram.org/bot$text/setwebhook?url=https://azadeen.cf/Ahmed/bots/$from_id/bot.php");


}


if($text and in_array($from_id, $getid) and $check->ok != "true" and !strpos($ch1 , '"status":"left"') !== false){

bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>'عذرا ❗️هاذا التوكن غير صالح ❌

- Sorry ! This Token is worng ❌',
'reply_to_message_id'=>$message->message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'العودة | Back','callback_data'=>'cancle']]
]
])
]);
}    

if($data == 'cancle' and in_array($from_id, $getid)){

$str = str_replace($chat_id2, "", $get_id) ;
file_put_contents('make/make.txt', $str);
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>"
🚸┊اهلا بك $namee 👋

♡┊في بوت صنع بوتات حماية ⚙️🔒

♡┊من احدث المصانع حماية مجموعات✅.

♡┊عدم توقف البوتات المصنوعة لمدة 24س✅.

♡┊تستطيع تغيير حقوق بوتك باي وقت وبسهولة💻.

♡┊اصنع بوتك الان مجاني للابد✅. 

♡┊لصنع بوت جديد اضغط صنع بوت 
📡 CH - @BB55Il
👨‍💻 DEV - @CIJlX



",
'reply_markup'=>json_encode([
'inline_keyboard'=>[

[['text'=>'صنع بوت 📮','callback_data'=>'maka'],['text'=>'حذف بوت 🗑 ','callback_data'=>'delete']
],
[
['text'=>'المطور ♻','url'=>'t.me/@CIJlX']
],
[['text'=>'قناتنا 📢','url'=>'https://t.me/BB55Il'] ,
['text'=>'شارك البوت 🔁','switch_inline_query'=>'']
],
[
['text'=>'بوتاتي المصنوعة 🤖','callback_data'=>'mybots'],['text'=>"",'callback_data'=>"update"]
],
[['text'=>'معلومات حسابي 👤','callback_data'=>'info']],


]
])
]);
}
if($data == 'home'){
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>"
🚸┊اهلا بك $namee 👋

♡┊في بوت صنع بوتات حماية ⚙️🔒

♡┊من احدث المصانع حماية مجموعات✅.

♡┊تستطيع تغيير حقوق بوتك باي وقت وبسهولة💻.

♡┊اصنع بوتك الان مجاني للابد✅. 

♡┊لصنع بوت جديد اضغط صنع بوت 
📡 CH - @BB55Il
👨‍💻 DEV - @CIJlX



",
'reply_markup'=>json_encode([
'inline_keyboard'=>[

[['text'=>'صنع بوت 📮','callback_data'=>'maka'],['text'=>'حذف بوت 🗑 ','callback_data'=>'delete']
],
[
['text'=>'المطور ♻','url'=>'t.me/@CIJlX']
],
[['text'=>'قناتنا 📢','url'=>'https://t.me/BB55Il'] ,
['text'=>'شارك البوت 🔁','switch_inline_query'=>'']
],
[
['text'=>'بوتاتي المصنوعة 🤖','callback_data'=>'mybots'],['text'=>"",'callback_data'=>"update"]
],
[['text'=>'معلومات حسابي 👤','callback_data'=>'info']],


]
])
]);
}
if($data == 'delete' and in_array($chat_id2,$done)){
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>'هل انت متأكد ⁉️ 

- Are you sure ?!',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'لا ❌', 'callback_data'=>'home'],
['text'=>'نعم ✅','callback_data'=>'yesdel'],
]    
]])
]);    
}

if($data == 'yesdel' and in_array($chat_id2, $done)){


bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>"- تم بنجاح حذف البوت 🗑

- Bot has been successfully deleted 🗑",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'العودة | Back' , 'callback_data'=>"home"]
]
]
])
]);



$str1 = str_replace($chat_id2, '', $get_done);

file_put_contents('make/ex.txt', $str1);

$get_token = file_get_contents("bots/$chat_id2/info.php");

$get_url = file_get_contents("https://api.telegram.org/bot$get_token/getWebhookInfo");

$json = json_decode($get_url);

$url = $json->result->url;

file_get_contents("https://https://api.telegram.org/bot$get_token/deletewebhook?url=$url");

unlink("bots/$chat_id2/bot.php");
unlink("bots/$chat_id2/info.php");

}


if($data == 'delete' and !in_array($chat_id2,$done)){

bot('answerCallbackQuery',[
'callback_query_id'=>$update->callback_query->id,
'message_id'=>$message_id,
'text'=>'قم بانشاء بوت اولا

- Create a Bot First ',
 'show_alert'=>true
 ]);  
 
}




if($data == 'info' and in_array($chat_id2,$done)){
    
$get_info = file_get_contents("bots/$chat_id2/info.php");

$url_info = file_get_contents("https://api.telegram.org/bot$get_info/getMe");

$json_info = json_decode($url_info);

$id = $json_info->result->id;

$user = $json_info->result->username;

$name = $json_info->result->first_name;

bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>"
*Your Info*

💳 Your ID :- `$idss`

👤 Your Username :- @$userr

🚸 Your Name :- $namee

",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'العودة | Back' , 'callback_data'=>"home"]
]
]
])
]);    
}

if($data == 'info' and !in_array($chat_id2,$done)){
bot('answerCallbackQuery',[
'callback_query_id'=>$update->callback_query->id,
'message_id'=>$message_id,
'text'=>'قم ♻️ بأنشاء بوت اولا ~💟',
 'show_alert'=>true
 ]);  
}

if($data == 'buy'){
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>"

",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'المطور 🕴🏻','url'=>'https://telegram.me/BB55Il']],
[['text'=>'بوت التواصل 💎','url'=>'https://telegram.me/BB55Il']],
[['text'=>'الصفحة الرئيسية 🏠️' , 'callback_data'=>"home"]]
]])
]);
}

if($data=="channel"){
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>'تابعنا عبر الروابط للتالية 📩',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[
['text'=>'phpfiles', 'url'=>"https://telegram.me/BB55Il"]
],
[
['text'=>'مطور البـوت.!‹', 'url'=>"https://telegram.me/BB55Il"]
],
[
['text'=>'عودة 🏠 ', 'callback_data'=>"home"]
],
]
])
]);
}
if($data == 'update' and !in_array($chat_id2,$done) and !strpos($ch1 , '"status":"left"') !== false){
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>'- قم بصنع بوت اولا لتحديثه ❌',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'الصفحة الرئيسية 🏚','callback_data'=>'home']]    
]
])
]);
}
if($data == 'update' and in_array($chat_id2,$done) and !strpos($ch1 , '"status":"left"') !== false){
unlink("bots/$from_id/bot.php");
file_put_contents("bots/$from_id/bot.php", $get_file1); 
	bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>'- تم بنجاح تحديث بوتك ✅',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'الصفحة الرئيسية 🏚','callback_data'=>'home']]    
]
])
]);
}
if($data == 'mybots' and !in_array($chat_id2,$done) and !strpos($ch1 , '"status":"left"') !== false){
	file_put_contents('make/make.txt', "\n" . $chat_id2 . "\n",FILE_APPEND);    
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>'عدد بوتاتك المصنوعة هو :- 0',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'الصفحة الرئيسية 🏚','callback_data'=>'home']]    
]
])
]);
}
if($data == 'mybots' and in_array($chat_id2,$done) and !strpos($ch1 , '"status":"left"') !== false){
bot('editMessageText',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id,
'text'=>"عدد بوتاتك المصنوعة هي :- 1

$un",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'الصفحة الرئيسية 🏚','callback_data'=>'home']]    
]
])
]);
}
/////
$MASTAFAFILES = '902816989' ايديك;
if($text == '/admin' and $chat_id == $MASTAFAFILES){ 
bot('sendMessage',[ 
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
'chat_id'=>$chat_id, 
'text'=>' أهلا بك عزيزي المدير
في قائمة الأوامر الخاصة بك؛
إضغط على أحد الأوامر لتنفيذه الآن',
'reply_markup'=>json_encode([ 
'keyboard'=>[ 
[
['text'=>'❖￤نشر عام 📢'],['text'=>'❖￤نشر توجيه 🔁']
],
[
['text'=>'❖￤نشر ماركدوان 📣']
],
[ 
['text'=>'❖￤عدد البوتات 🤖'],['text'=>'❖￤المشتركين 👥']
],
[
['text'=>'❖￤الأحصائيات 📊']
],
] 
]) 
]); 
}
 
$MASTAFAFILES = ايديك;
$MA3TAFA = explode("\n",file_get_contents("MASTAFA.txt"));
$MASTAFA = count($MA3TAFA)-1;
$MASTAFA_DEV = file_get_contents("MASTAFA_DEV.txt");
if ($update && !in_array($chat_id, $MA3TAFA)) {
file_put_contents("MASTAFA.txt", $chat_id."\n",FILE_APPEND);
}
if($text == "❖￤المشتركين 👥" and $chat_id == $MASTAFAFILES){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"❖￤عدد مشتركين بوتك سيدي المطور هو { $MASTAFA } مشترك ؛ 👥"
]);
}

$count = count(scandir('bots')) - 2;
if($text == "عدد البوتات" and $chat_id == $MASTAFAFILES){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"❖￤عدد البوتات المصنوعة سيدي المطور هو { $count$botss} بوت ؛ 👥"
]);
}
if($text == "❖￤الأحصائيات 📊" and $chat_id == $MASTAFAFILES){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"❖￤اليك الاحصائيات 📈
📍¦ عدد البوتات المصنوعة { $count$botss} بوت ؛ 🤖
📍¦ عدد المشتركين هو { $MASTAFA }"
]);
}

if($text == "❖￤نشر عام 📢" and $chat_id == $MASTAFAFILES){
file_put_contents("MASTAFA_DEV.txt", "MASTAFA");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"❖￤ارسل رسالتك الان سيدي المطور وسيتم ارسالها الى { $MASTAFA } مشترك ؛ 📬"
]);
}

if($text != "❖￤نشر عام 📢" and $MASTAFA_DEV == "MASTAFA" and $chat_id == $MASTAFAFILES){
for ($i=0; $i < count($MA3TAFA); $i++) { 
bot('sendMessage',[
'chat_id'=>$MA3TAFA[$i],
'text'=>$text,
]);
}
unlink("MASTAFA_DEV.txt");
}
 
if($text == "❖￤نشر ماركدوان 📣" and $chat_id == $MASTAFAFILES){
file_put_contents("MASTAFA_DEV.txt", "MASTAFA1");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"❖￤ارسل رسالتك الان سيدي المطور وسيتم ارسالها الى { $MASTAFA } مشترك ؛ 📬"
]);
}
if($text != "❖￤نشر ماركدوان 📣" and $MASTAFA_DEV == "MASTAFA1" and $chat_id == $MASTAFAFILES){
for ($i=0; $i < count($MA3TAFA); $i++) { 
bot('sendMessage',[
'chat_id'=>$MA3TAFA[$i],
'text'=>$text,
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
]);
}
unlink("MASTAFA_DEV.txt");
}
$from = $message->from->id;
$message_id = $update->message->id;
$chat_id = $message->chat->id;
if($text == "❖￤نشر توجيه 🔁" and $chat_id == $MASTAFAFILES){
file_put_contents("MASTAFA_DEV.txt", "MASTAFA2");
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"❖￤ارسل رسالتك الان سيدي المطور وسيتم ارسالها الى { $MASTAFA } مشترك ؛ 📬",]);}
 //====================@CIJlX===================//
if($text != "❖￤نشر توجيه 🔁" and $MASTAFA_DEV == "MASTAFA2" and $chat_id == $MASTAFAFILES){
for($i=0;$i<count($MA3TAFA); $i++){
bot('forwardMessage', [
'chat_id' => $MA3TAFA[$i],
'from_chat_id'=>$from,
'message_id'=>$message->message_id
]);
}
unlink("MASTAFA_DEV.txt");
}



